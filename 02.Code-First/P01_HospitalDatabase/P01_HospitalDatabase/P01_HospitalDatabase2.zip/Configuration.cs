﻿namespace P01_HospitalDatabase
{
    class Configuration
    {
        public static string ConnectionString { get; set; } = @"Server=(localdb)\MSSQLLocalDB;Database=Hospital;Integrated Security=True";
    }
}
