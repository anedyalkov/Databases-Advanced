﻿namespace P03_SalesDatabase.Data
{
    class Configuration
    {
        public static string ConnectionString { get; set; } = @"Server=(localdb)\MSSQLLocalDB;Database=Sales;Integrated Security=True";
    }
}
